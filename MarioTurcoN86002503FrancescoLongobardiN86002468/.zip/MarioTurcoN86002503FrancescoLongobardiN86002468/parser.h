int appendPlayer(char *name, char *pwd, char *file);
int isRegistered(char *name, char *file);
int openFileRDWRAPP(char *file);
int validateLogin(char *name, char *pwd, char *file);
int openFileRDON(char *file);
void premiEnterPerContinuare();